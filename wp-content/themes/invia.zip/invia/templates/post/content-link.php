<?php get_template_part('templates/post/content-meta'); ?>

<div class="blogContent">
	<?php get_template_part('templates/post/content-tags'); ?>

			<?php get_template_part('templates/post/content-read-more'); ?>
</div>
