<div class="sidebar">
	<?php ct_dynamic_sidebar(); ?>
</div>
