<?php
/**
 * Interface which indicates that shortcode operates on single item
 * @author alex
 */
 
interface ICtShortcodeSingleQueryable {

}
