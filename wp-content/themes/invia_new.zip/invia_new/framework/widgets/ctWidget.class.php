<?php
/**
 * Base widget
 * @author alex
 */

abstract class ctWidget extends WP_Widget{

}
