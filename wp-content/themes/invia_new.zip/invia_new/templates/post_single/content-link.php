<?php get_template_part('templates/post_single/content-meta'); ?>

<div class="blogContent">
	<?php get_template_part('templates/post_single/content-tags'); ?>
</div>
